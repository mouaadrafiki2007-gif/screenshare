package com.example.screenshare

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.widget.*

class MainActivity : Activity() {
    private lateinit var pinInput: EditText
    private lateinit var status: TextView
    private var pin = ""

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val crashFile = java.io.File(filesDir, "crash.txt")
        Thread.setDefaultUncaughtExceptionHandler { _, e ->
            try { crashFile.writeText(android.util.Log.getStackTraceString(e)) } catch (_: Exception) {}
            android.os.Process.killProcess(android.os.Process.myPid())
            System.exit(10)
        }
        if (Build.VERSION.SDK_INT >= 33)
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48)
        }
        pinInput = EditText(this).apply {
            hint = "PIN (4 إلى 8 أرقام)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        val start = Button(this).apply { text = "بدا المشاركة" }
        val stop = Button(this).apply { text = "وقف" }
        status = TextView(this).apply { textSize = 18f; setPadding(0, 48, 0, 0) }
        if (crashFile.exists()) {
            status.textSize = 11f
            status.setTextIsSelectable(true)
            status.text = "آخر خطأ:\n" + crashFile.readText().take(1800)
            crashFile.delete()
        }
        l.addView(pinInput); l.addView(start); l.addView(stop); l.addView(status)
        setContentView(l)

        start.setOnClickListener {
            pin = pinInput.text.toString()
            if (!Regex("\\d{4,8}").matches(pin)) {
                status.text = "PIN خاصو يكون 4 إلى 8 أرقام"; return@setOnClickListener
            }
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), 100)
        }
        stop.setOnClickListener {
            stopService(Intent(this, ScreenService::class.java))
            status.text = "تّوقف البث"
        }
    }

    @Deprecated("simple")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 100 && res == RESULT_OK && data != null) {
            val i = Intent(this, ScreenService::class.java)
                .putExtra("code", res).putExtra("data", data).putExtra("pin", pin)
            startForegroundService(i)
            val ips = localIps()
            status.text = if (ips.isEmpty()) "ما لقيتش شبكة. دير WiFi أو Hotspot."
            else "فتح فالمتصفح:\n" + ips.joinToString("\n") { "http://$it:8080" }
        }
    }
}
