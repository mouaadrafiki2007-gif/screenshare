package com.example.screenshare

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import java.io.ByteArrayOutputStream

class ScreenService : Service() {
    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var server: WebServer? = null
    private val thread = HandlerThread("capture").apply { start() }
    private var last = 0L

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, f: Int, id: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("share", "Share", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "share")
            .setContentTitle("مشاركة الشاشة خدامة")
            .setSmallIcon(android.R.drawable.ic_menu_share).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)

        val code = intent.getIntExtra("code", 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent.getParcelableExtra("data", Intent::class.java)
        else @Suppress("DEPRECATION") intent.getParcelableExtra("data")
        val pin = intent.getStringExtra("pin") ?: return START_NOT_STICKY
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val handler = Handler(thread.looper)
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, handler)

        val dm = resources.displayMetrics
        val scale = minOf(1f, 720f / dm.widthPixels)
        val w = (dm.widthPixels * scale).toInt() / 2 * 2
        val h = (dm.heightPixels * scale).toInt() / 2 * 2

        server = WebServer(8080, pin).also { it.start() }
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd = projection!!.createVirtualDisplay("share", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)

        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = SystemClock.uptimeMillis()
                val s = server
                if (s == null || s.clients.get() == 0 || now - last < 100) return@setOnImageAvailableListener
                last = now
                val p = img.planes[0]
                val padded = p.rowStride / p.pixelStride
                val buf = java.nio.ByteBuffer.allocate(p.rowStride * h)
                buf.put(p.buffer); buf.rewind()
                var bmp = Bitmap.createBitmap(padded, h, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(buf)
                if (padded != w) bmp = Bitmap.createBitmap(bmp, 0, 0, w, h)
                val out = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, 60, out)
                s.frame = out.toByteArray()
            } finally { img.close() }
        }, handler)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        server?.stop(); vd?.release(); reader?.close()
        projection?.stop(); thread.quitSafely()
        super.onDestroy()
    }
}
