package com.example.screenshare

import java.io.OutputStream
import java.net.*
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

fun localIps(): List<String> = try {
    NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
        .filter { it is Inet4Address && it.isSiteLocalAddress }.map { it.hostAddress!! }
} catch (e: Exception) { emptyList() }

class WebServer(private val port: Int, private val pin: String) {
    @Volatile var frame: ByteArray? = null
    val clients = AtomicInteger(0)
    private val tokens = ConcurrentHashMap.newKeySet<String>()
    private val fails = ConcurrentHashMap<String, LongArray>() // ip -> [count, lockUntil]
    private var ss: ServerSocket? = null

    fun start() {
        thread(isDaemon = true) {
            try { ss = ServerSocket(port) } catch (e: Exception) { return@thread }
            while (ss?.isClosed == false) {
                try { val s = ss!!.accept(); thread { handle(s) } } catch (_: Exception) {}
            }
        }
    }
    fun stop() { try { ss?.close() } catch (_: Exception) {} }

    private fun handle(s: Socket) {
        try {
            s.use {
                val inp = s.getInputStream().bufferedReader()
                val out = s.getOutputStream()
                val line = inp.readLine() ?: return
                val target = line.split(" ").getOrNull(1) ?: "/"
                var cookie = ""
                while (true) {
                    val h = inp.readLine()
                    if (h.isNullOrEmpty()) break
                    if (h.startsWith("Cookie:", true)) cookie = h.substring(7)
                }
                val path = target.substringBefore("?")
                val query = target.substringAfter("?", "")
                val tok = Regex("tok=([a-f0-9]+)").find(cookie)?.groupValues?.get(1)
                val authed = tok != null && tokens.contains(tok)
                val ip = s.inetAddress.hostAddress ?: "?"

                when {
                    path == "/login" -> login(out, ip, query)
                    path == "/stream" && authed -> stream(out)
                    path == "/stream" -> send(out, 401, "text/plain", "Unauthorized")
                    authed -> send(out, 200, "text/html", VIEWER)
                    else -> send(out, 200, "text/html", loginPage(""))
                }
            }
        } catch (_: Exception) {}
    }

    private fun login(out: OutputStream, ip: String, query: String) {
        val f = fails.getOrPut(ip) { longArrayOf(0, 0) }
        val now = System.currentTimeMillis()
        if (now < f[1]) { send(out, 429, "text/html", loginPage("برا شوية وعاود (محاولات كثيرة)")); return }
        val given = URLDecoder.decode(query.substringAfter("pin=", "").substringBefore("&"), "UTF-8")
        if (MessageDigest.isEqual(given.toByteArray(), pin.toByteArray())) {
            f[0] = 0
            val b = ByteArray(16).also { SecureRandom().nextBytes(it) }
            val t = b.joinToString("") { "%02x".format(it) }
            tokens.add(t)
            out.write(("HTTP/1.1 302 Found\r\nLocation: /\r\nSet-Cookie: tok=$t; Path=/; HttpOnly; SameSite=Strict\r\nContent-Length: 0\r\nConnection: close\r\n\r\n").toByteArray())
        } else {
            f[0]++
            if (f[0] >= 5) { f[1] = now + 60_000; f[0] = 0 }
            send(out, 403, "text/html", loginPage("PIN غالط"))
        }
    }

    private fun stream(out: OutputStream) {
        clients.incrementAndGet()
        try {
            out.write("HTTP/1.1 200 OK\r\nContent-Type: multipart/x-mixed-replace; boundary=f\r\nCache-Control: no-cache\r\nConnection: close\r\n\r\n".toByteArray())
            var last: ByteArray? = null
            while (ss?.isClosed == false) {
                val f = frame
                if (f != null && f !== last) {
                    out.write("--f\r\nContent-Type: image/jpeg\r\nContent-Length: ${f.size}\r\n\r\n".toByteArray())
                    out.write(f); out.write("\r\n".toByteArray()); out.flush()
                    last = f
                }
                Thread.sleep(40)
            }
        } catch (_: Exception) {
        } finally { clients.decrementAndGet() }
    }

    private fun send(out: OutputStream, code: Int, type: String, body: String) {
        val b = body.toByteArray()
        out.write("HTTP/1.1 $code OK\r\nContent-Type: $type; charset=utf-8\r\nContent-Length: ${b.size}\r\nConnection: close\r\n\r\n".toByteArray())
        out.write(b); out.flush()
    }

    private fun loginPage(msg: String) = """<!doctype html><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1">
<body style="font-family:sans-serif;text-align:center;margin-top:20vh;direction:rtl">
<h2>دخل PIN</h2><form action=/login>
<input name=pin type=password inputmode=numeric autofocus style="font-size:24px;text-align:center">
<br><br><button style="font-size:20px">دخول</button></form>
<p style=color:red>$msg</p>"""

    companion object {
        const val VIEWER = """<!doctype html><meta charset=utf-8>
<meta name=viewport content="width=device-width,initial-scale=1">
<body style="margin:0;background:#000">
<img src=/stream style="width:100vw;height:100vh;object-fit:contain">"""
    }
}
